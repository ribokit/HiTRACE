<?php
	include "php/inc/check_pid.php";

$path = "./tmp_data/" . $pid ;

if(!file_exists($path)) {
	die("Job ID is not found.");
}

$stat = file_get_contents($path . "/stat");
// data file type check
switch($stat) {
	case -5:
		header("Location: ./initialize.php?pid=$pid");	
		break;
	case 0:
		file_put_contents($path . "/stat", "-5");
		header("Location: ./check.php?pid=$pid");
		break;
	case 1:
		if(!isset($_GET["data"]) || !isset($_GET["rdat"])) {
			file_put_contents($path . "/stat", "-5");
			header("Location: /check.php?pid=$pid");
			break;
		}
		$dataname = $_GET["data"];
		$rdatname = $_GET["rdat"];
		exec("unzip $path/$dataname -d $path/scratch/data/");
		$list = shell_exec("ls -l $path/scratch/data/ | grep ^d | awk '{ printf \"scratch/data/%s\\n\", $9}'");
		$list = str_replace("scratch/data/__MACOSX\n","", $list);
		if(empty($list)) {
			$list = "scratch/data";
		}
		file_put_contents($path . "/filelist.txt", $list);
		exec("mv $path/$rdatname $path/rdat.txt");
		header("Location: ./php/basic_align.php?pid=$pid");
		break;
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
		header("Location: ./viewer.php?pid=$pid");
		break;
}
?>
