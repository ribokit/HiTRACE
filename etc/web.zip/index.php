<?php
	$path = "./tmp_data/";

	$stat = file_get_contents($path . "stat");
	if($stat == FALSE) {
		$stat = 0;
	}
?>

<html>
<head>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript">
		<?php
			echo "var stat = $stat;";
		?>

		window.onload = function() {
			if(stat == 0 || stat == 7) {
				$("#busy").hide();
				$("#create").show();
			} else {
				$("#create").hide();
				$("#busy").show();
			}
		}
	</script>
	<title>Welcome To HiTRACE Web ver.</title>
</head>
<body>
<div>
	<p id="create">
		To create new job, click the follow link<br/>
		<a href="initialize.php">Create New Job</a>
	</p>
	<p id="busy">
		Job is running on. Please wait and refresh until the previos job is done.
	</p>
	<p>
		To confirm the previous request, enter your job code.
		<form action="check.php" method="get">
			<input type="text" name="pid" size="32" value=""/>
			<input type="submit" value="View"/>
		</form>
	</p>
</div>
</body>
</html>
