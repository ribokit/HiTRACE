var fig = [false, false, false, false];
var grp_size = 1;

window.onload = function() {
	$("#submit_btn").hide();
	$("#down_btn").hide();
	$("#revert").hide();
	$("#down_btn").click(function() {
			location.assign("php/down_areapeak.php?pid="+pid);
			});
	
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			var raw_result = xmlhttp.responseText;
			result = Number(raw_result);
			if(result > 4) {
				var grp_rqst = new XMLHttpRequest();
				$.ajax({
					type : "GET",
					url : "php/getgroupsize.php?pid=" + pid,
					success : function(data) {	
						grp_size = Number(data);
						$("#group_size").html(grp_size + " profiles are established.");
						},
					async : false});
			}
			switch(result) {
				case 7:
					if(!fig[3]) {
						for(var i = grp_size; i >= 1 ; i--) {
							$("#loadingImg").after("<p><table class=\"image\"><caption> Fitting result - sequence " +
									i + " </caption><tr><td><img src=\"tmp_data/"+pid+"/fitting" + i + ".png\"/></td></tr></table></p>");
						}
						fig[3] = true;
						$("#loadingImg").hide();
						$("#down_btn").show();
						$("#submit_btn").show();
						$("#submit_btn").val("re-annotate");
						clearTimeout(msgSet);
					}
				case 6:
					if(result == 6) {
						$("#loadingImg").show();
						$("#submit_btn").hide();
					}
				case 5:
					if(!fig[2]) {
						$("#loadingImg").after("<p><table class=\"image\"><caption> Baseline adjusted image </caption><tr><td><img src=\"tmp_data/"+pid+"/scratch/figure3.png\"/></td></tr></table></p>");
						
						if(result == 5) {
							$("#submit_btn").show();
							$("#loadingImg").hide();
						}
						fig[2] = true;
					}
				case 4:
					if(!fig[1]) {
						$("#loadingImg").after("<p><table class=\"image\"><caption> Non-linear aligned image </caption><tr><td><img src=\"tmp_data/"+pid+"/scratch/figure2.png\"/></td></tr></table></p>");
						fig[1] = true;
					}
				case 3:
					if(!fig[0]) {
						$("#loadingImg").after("<p><table class=\"image\"><caption> Global linear alinged image </caption><tr><td><img src=\"tmp_data/"+pid+"/scratch/figure1.png\"/></td></tr></table></p>");
						fig[0] = true;
					}
					break;
				case 2:
				case 1:
				case -5:
					break;
				default:
					$("#status").html(raw_result);					
					clearTimeout(msgSet);
					$("#loadingImg").hide();
					$("#revert").show();
			}
		}
	}

	var msgSet = setInterval(function() {sendAJAX();}, 1000);

	function sendAJAX() {
		xmlhttp.open("get", "php/monitor.php?pid=" + pid, true);
		xmlhttp.send();
	}
}
