window.onload=function() {
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			var result = xmlhttp.responseText;
			result = Number(result);

			if(result == 6) {
				$.get("php/getgroupsize.php",function(data, status) {
						$("#loadingImg").hide();
						var grpsize = Number(data);

						for(var i = 1; i <= grpsize; i++) {
							$("#loadingImg").before("<img src=\"./tmp_data/fitting"+i +".png\" />");
						}
					});

				clearTimeout(msgSet);
			}
				
		}
	}

	var msgSet = setInterval(function() {sendAJAX();}, 1000);
	function sendAJAX() {
		xmlhttp.open("get", "php/monitor.php", true);
		xmlhttp.send();
	}
}
