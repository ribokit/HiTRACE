// new canvas object for image buffer
// jquery is required.

function saveXsel() {
	if(xsel.length == 0) {
		alert('at least one more annotation need!');
		return false;
	}
	$.ajax({
			type: 'POST',
			url: "./php/save_xsel.php",
			data : { 
				xsel: xsel.toString(),
				pid: pid,
				gid: gid,
				},
			success: function(data) {
				if(data == "success")
					alert("annotation saved!");
				},
			async: false});
	
	var frm = document.getElementById("submit_frm");

	if(gid < grp_size) {
		frm.action = "mark_sequence_working.php";
		$("#gid").val(gid+1);
	} else {
		frm.action = "php/fitting.php";
		$("#gid").val(gid);
	}
	$("#pid").val(pid);
	return true;
}

function updateOriginalImage(intensity) {
	var orgCanvas = document.getElementById("orgLayer");
	var width = orgCanvas.width;
	var height = orgCanvas.height;

	var ctx = orgCanvas.getContext("2d");
	var imgData = ctx.createImageData(width, height);

	var factor = Math.pow(Math.sqrt(2), intensity - 1) * 40;

	for(var i = 0; i < height; i ++) {
		for(var j = 0; j < width; j++) {
			var pix = Math.round(data[i][j] * factor) - 1;
			pix = pix < 0 ? 0 : ( pix > 99 ? 99 : pix);

			var idx = j*4 + i*width*4;

			imgData.data[idx] = colormap[pix]; 
			imgData.data[idx+1] = colormap[pix]; 
			imgData.data[idx+2] = colormap[pix]; 
			imgData.data[idx+3] = 255; 

		}
	}

	ctx.putImageData(imgData, 0, 0);
}

function changeIntensity() {
	var ratio = $("#int_range").val();
	$("#int_view").html("intensity: x" + ratio);
	updateOriginalImage(ratio);
	drawBackground();	
}

function changeSize() {
	var ratio = $("#zoom_range").val();
	$("#zoom_view").html("Zoom: x" + ratio);
	updateStage();
}

function resetChange() {
	$("#int_range").val(1);
	$("#zoom_range").val(1);
	
	$("#int_range").change();
	$("#zoom_range").change();

}

function updateStage() {
	var ratio = $("#zoom_range").val() * 100;

	$("canvas#bgLayer").height(ratio + "%");
	$("canvas#charLayer").height(ratio + "%");
	$("canvas#lineLayer").height(ratio + "%");
	$("canvas#aimLayer").height(ratio + "%");

	var width = $("canvas#bgLayer").width();
	var height = $("canvas#bgLayer").height();
	$("canvas#bgLayer").width = width;
	$("canvas#bgLayer").height = height;
	
	width = $("canvas#lineLayer").width();
	height = $("canvas#lineLayer").height();
	$("canvas#lineLayer").width = width;
	$("canvas#lineLayer").height = height;
	
	width = $("canvas#aimLayer").width();
	height = $("canvas#aimLayer").height();
	$("canvas#aimLayer").width = width;
	$("canvas#aimLayer").height = height;
	
	width = $("canvas#charLayer").width();
	height = $("canvas#charLayer").height();
	$("canvas#charLayer").width = width;
	$("canvas#charLayer").height = height;
	
	drawBackground();
	drawLines();
	drawSequence();
	initialAim();
}

function drawLines() {
	var canvas_width = $("canvas#lineLayer").width();
	var canvas_height = $("canvas#lineLayer").height();
	var canvas = document.getElementById("lineLayer");
	canvas.width = canvas_width;
	canvas.height = canvas_height;

	var ctx = canvas.getContext("2d");		
	ctx.clearRect(0,0,canvas_width, canvas_height);

	$("#xsel_panel").html("");
	for(var i = 0; i < xsel.length; i++) {
		addLine(i);
	}
}

function drawSequence() {
	var canvas_width = $("canvas#charLayer").width();
	var canvas_height = $("canvas#charLayer").height();
	var canvas = document.getElementById("charLayer");
	canvas.width = canvas_width;
	canvas.height = canvas_height;

	var ctx = canvas.getContext("2d");		
	ctx.clearRect(0,0,canvas_width, canvas_height);

	var nucleotide;
	
	for(var i = 0; i < xsel.length; i++) {
		var y = returnY(xsel[i]);
		// Draw nucleotide
		if(sequence.length == 0 || i > sequence.length) {
			nucleotide = "N";
		} else {
			nucleotide = sequence.charAt(sequence.length - i -1 - dist);
		}
		nucleotide = nucleotide + (sequence.length - i - dist);

		ctx.font ="10px Arial";
		ctx.fillText(nucleotide, 0, y);

		// Draw hit circles
		if(i < area_pred.length) {
			var lineWidth = document.getElementById("lineLayer").width;
			var margin = (canvas.width - lineWidth ) / 2;
			var lineGap = lineWidth / area_pred[i].length;
			var padding = lineGap / 2;

			var xPos = margin + padding;
			for(var j = 0; j < area_pred[i].length; j++) {
				if(area_pred[i][j] == 1) {
					ctx.beginPath();
					ctx.arc(xPos, y,5,0,2*Math.PI);
					ctx.closePath();
					ctx.strokeStyle = "red";
					ctx.stroke();
				}
				xPos += lineGap;
			}
		}
	}
}

function addLine(index) {

	var line_margin = $("canvas#lineLayer").width() - $("canvas#bgLayer").width();
	line_margin /= 2;

	
	var realY = returnY(xsel[index]);

	var canvas = document.getElementById("lineLayer");
	var ctx = canvas.getContext("2d");
	ctx.beginPath();
	ctx.moveTo(line_margin , realY);
	ctx.lineTo(canvas.width - line_margin, realY);
	ctx.closePath();
	ctx.stroke();
}

function initialAim() {
	var canvas_width = $("canvas#aimLayer").width();
	var canvas_height = $("canvas#aimLayer").height();
	var canvas = document.getElementById("aimLayer");
	canvas.width = canvas_width;
	canvas.height = canvas_height;
}

function getClickAction() {
	var radio = document.getElementById("add");
	if(radio.checked == true)
		return true; // add action
	else
		return false; // del action
}

function clickEventHandler() {
	var y = event.clientY - $("canvas#aimLayer").offset().top;
	y = transCoordinate(y);
	
	if(getClickAction()) {
		xsel.push(y);
		xsel.sort(function(a,b){return a-b});
		addLine(xsel.indexOf(y));
	} else {
		var closest = closestXsel(y);
		if(closest != false) {
			xsel.splice(closest.minIdx, 1);
		} else {
			return;
		}
		drawLines();
	}
	drawSequence();
}

function closestXsel(y) {
	if(xsel.length > 0) {
		var min = document.getElementById("orgLayer").height;
		var min_idx = 0;
		for(var i = 0; i < xsel.length;i++) {
			var sub = Math.abs(xsel[i] - y);
			if(sub < Math.abs(min-y)) {
				min = xsel[i];
				min_idx = i;
			}
		}

		if(Math.abs(min - y) > 30) {
			return false;
		}

	} else {
		return false;
	}

	var obj = {"min": min,
		"minIdx": min_idx};
	return obj;
}


function mouseoverHandler() {
	var canvas_width = $("canvas#aimLayer").width();
	var canvas_height = $("canvas#aimLayer").height();
	var canvas = document.getElementById("aimLayer");
	var ctx = canvas.getContext("2d");

	var y = event.clientY - $("canvas#aimLayer").offset().top + window.pageYOffset;
	var str = "Moving at " + transCoordinate(y);
	$("#info_panel").html(str);
	ctx.clearRect(0,0,canvas_width, canvas_height);	
	ctx.beginPath();
	if(getClickAction()) {
		ctx.moveTo(0,y);
		ctx.lineTo(canvas_width, y);
	} else {
		var closest = closestXsel(transCoordinate(y));
		if(closest != false) {
			ctx.moveTo(0,returnY(closest.min));
			ctx.lineTo(canvas_width,returnY(closest.min));
		} else {
			ctx.moveTo(0,y);
			ctx.lineTo(canvas_width, y);
		}
	}
	ctx.closePath();
	ctx.strokeStyle = "red";
	ctx.stroke();
}

function mouseoutHandler() {
	var canvas_width = $("canvas#aimLayer").width();
	var canvas_height = $("canvas#aimLayer").height();
	var canvas = document.getElementById("aimLayer");
	var ctx = canvas.getContext("2d");

	$("#info_panel").html("");

	ctx.clearRect(0,0,canvas_width, canvas_height);	
}

function transCoordinate(y) {
	var orgCanvas = document.getElementById("orgLayer");
	var transY;
	transY = y * orgCanvas.height / $("canvas#bgLayer").height();
	return Math.round(transY);
}

function returnY(y) {
	var orgCanvas = document.getElementById("orgLayer"); 
	var coorY;
	coorY = y * $("canvas#bgLayer").height() / orgCanvas.height;
	return coorY;
}

function drawBackground() {
	var orgCanvas = document.getElementById("orgLayer");
	var canvas_width = $("canvas#bgLayer").width();
	var canvas_height = $("canvas#bgLayer").height();
	var canvas = document.getElementById("bgLayer");
	canvas.width = canvas_width;
	canvas.height = canvas_height;
	var ctx = canvas.getContext("2d");

	if(orgCanvas.width < canvas_width) {
		var max_iter = canvas_width / orgCanvas.width;
		for(var i = 0; i < orgCanvas.width; i++) {
			for(var j = 0; j < max_iter; j++)
			{
				ctx.drawImage(orgCanvas,
						i,0,1,orgCanvas.height, 
						j + max_iter*i, 0, 1, canvas_height);
			}
		}
	}
}

function clickAutoAssign() {
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if(xmlhttp.readyState == 4 && xmlhttp.status==200)
		{
			eval(xmlhttp.responseText);	
			$("#as_loadingImg").hide();
			$("#autoassign").show();
			updateStage();
		}
	}
	xmlhttp.open("GET", "php/auto_assign.php?gid="+gid+"&pid="+pid,true);
	xmlhttp.send();
	$("#as_loadingImg").show();
	$("#autoassign").hide();
}

window.onload = function() {
	$("input#int_range").change(changeIntensity);
	$("input#zoom_range").change(changeSize);
	$("input#reset_btn").click(resetChange);
	$("#autoassign").click(clickAutoAssign);

	$("canvas#aimLayer").mousemove(mouseoverHandler);
	$("canvas#aimLayer").mouseout(mouseoutHandler);
	$("canvas#aimLayer").click(clickEventHandler);
	
	var orgCanvas = document.getElementById('orgLayer');
	orgCanvas.width = data[0].length;
	orgCanvas.height = data.length;

	$("#title").html("Sequence " + gid + " / " + grp_size);

	updateOriginalImage(1);
	updateStage();
}
window.onresize = function() {updateStage();}
