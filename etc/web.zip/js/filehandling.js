var BLOCKSIZE = 65536;
var start = 0;
var fileElements = [ "datafile", "rdatfile"];
var fileIndex = 0; // 0 for data, 1 for RDAT
var pid = 0;

function startUpload() {
	var file = document.getElementById("datafile").files;
	if(!file.length) {
		alert("Please select a data file!");
		return;
	}
	file = document.getElementById("rdatfile").files;
	if(!file.length) {
		alert("Please select a RDAT file!");
		return;
	}

	$("#loading").show();
	$("#uploadBtn").hide();
	$("#datafile").attr("disabled", "disabled");
	$("#rdatfile").attr("disabled", "disabled");

	initialize();
}

function checkPID() {
	if(pid == 0) { 
		alert("failed to initialize!");
		$("#loading").hide();
		$("#uploadBtn").show();
		$("#datafile").attr("disabled", "");
		$("#rdatfile").attr("disabled", "");

	} else {
		$("#status").html("Your Job ID is \"" + pid + "\". Please remember!");
		upload();
	}
}

function initialize() {
	if(pid == 0) {
		$.ajax({url: "php/init.php", type: "get", success: function(data) {
					pid = data;
					checkPID();
				}});
	} else {
		$.ajax({url: "php/init.php?pid="+pid, type: "get", success: function(data) {
					pid = data;
					checkPID();
				}});

	}
}

function upload() {
	if(fileIndex < 2) {
		var file = document.getElementById(fileElements[fileIndex]).files[0];
		
		var reader = new FileReader();

		reader.onloadend = function(evt) {
			if(evt.target.readyState == FileReader.DONE) {
				var data = evt.target.result;
				var encoded_data = Base64.encode(data);
				var file = document.getElementById(fileElements[fileIndex]).files[0];
				$.post("php/upload.php", {action:"upload", filename : file.name, data: encoded_data, pid: pid},
						function(data, status) {
							if(data == "success") {
								var file = document.getElementById(fileElements[fileIndex]).files[0];
								var ratio = Math.min(Math.round(start / file.size * 100), 100);
								$("#percent"+fileIndex).html(ratio + "% done");
								if(start >= file.size) {
									start = 0;
									fileIndex++;
								}
								upload();
							} else if(data == "already") {
								alert("Data exists already.");
							} else {
								alert(data);
							}
						});
			}
		}

		var next_start = start + BLOCKSIZE;
		var blob = file.slice(start, next_start);
		reader.readAsBinaryString(blob);
		start = next_start;
	} else {
		$.post("php/upload.php", {action:"done", pid: pid},
				function(data, status) {
					if(data == "success") {
						$("#loading").hide();
						$("#submit_frm").show();
					}
				});

	}
}
