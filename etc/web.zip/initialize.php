<html>
<head>
<title>Welcome To HiTRACE Web ver.</title>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/filehandling.js" type="text/javascript"></script>
<script src="js/base64.js" type="text/javascript"></script>
<script type="text/javascript">
<?php
	if(isset($_GET["pid"])) {
		echo "pid = \"" . $_GET["pid"] . "\";";
	}

?>
window.onload = function() {
	$("#loading").hide();
	$("#submit_frm").hide();
}

function submitClick() {
	var datafile = document.getElementById("datafile").files[0];
	var rdatfile = document.getElementById("rdatfile").files[0];

	$("#data").val(datafile.name);
	$("#rdat").val(rdatfile.name);
	$("#pid").val(pid);

	return true;
}
</script>
<link rel="stylesheet" type="text/css" href="css/input_form.css"/>
</head>
<body>
<div id="basic_panel">
	<label for="datafile">Datafile</label>
	<input type="file" name="datafile" id="datafile"/> 
	<div class="progress_bar">
		<span id="percent0" class="percent">0% done</span>
	</div>
	<br/>
	
	<label for="rdatfile">RDAT annotation file</label>
	<input type="file" name="rdatfile" id="rdatfile"/> 
	<div class="progress_bar">
		<span id="percent1" class="percent">0% done</span>
	</div>
	<br/>

	<button id="uploadBtn" onclick="startUpload()">Upload</button>

	<div id="status"></div>

	<form id="submit_frm" onsubmit="submitClick();" action="check.php" method="get">
		<input type="hidden" name="data" id="data"/>
		<input type="hidden" name="rdat" id="rdat"/>
		<input type="hidden" name="pid" id="pid"/>
		<input type="submit" value="Start!"/>
	</form>

	<img src="img/loading.gif" id="loading"/>
</div>
<div id="advanced_panel">

</div>
</body>
</html>
