GUI/		GUI files (MATLAB)
Scripts/	HiTRACE scripts (MATLAB)
Standalone/	HiTRACE scripts (Standalone)
TestData/	Test data

* For quick start, run GUI/HiTRACE_GUI.m.
* Refer to GUI/README.pdf for help on HiTRACE GUI.

