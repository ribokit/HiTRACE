fid = fopen('../tmp_data/stat', 'w');
fprintf(fid, '0');
fclose(fid);

i = 0;
while(1)
	i = i + 1;
	pause(3);
	fid = fopen('../tmp_data/stat', 'w');
	fprintf(fid, '%d', i);
	fclose(fid)
end
