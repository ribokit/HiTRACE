% initialize variable
addpath(genpath('../../matlab/hitrace/Scripts'));
addpath(genpath('../../matlab/util'));
path = '${path}';
stat = '${jobstat}';
grp_size = ${grp_size};

for i = 1:grp_size
	data = load(sprintf('%sdata%d.txt',path,i), '-ascii');
	xsel = load(sprintf('%sxsel%d.txt',path,i), '-ascii');

	if(~isempty(xsel))
		area_peak = do_the_fit_fast(data, xsel, 0.0, 1);
		save(sprintf('%sarea_peak%d.txt',path,i), '-ascii', 'area_peak');
		print(sprintf('%sfitting%d.png',path,i), '-dpng');
	end
end

print_stat(7,stat);
