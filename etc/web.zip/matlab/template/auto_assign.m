% initialize variable
addpath(genpath('../../matlab/auto_assign'));
path = '${path}';
output = '${output}';
sequence = '${sequence}';
gid = ${gid};
dist = ${dist};

datafile = [path, sprintf('data%d.txt', gid)];
predfile = [path, sprintf('area_pred%d.txt',gid)];

data = load(datafile, '-ascii');
area_pred = load(predfile, '-ascii');

xsel = auto_assign_sequence(data, sequence(1:end-dist), [], [], area_pred, [], []);

fid = fopen(output, 'w');
for i = xsel
	fprintf(fid,'%d\t', i);
end
fclose(fid);
