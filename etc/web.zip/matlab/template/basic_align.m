% initialize variable
addpath(genpath('../../matlab/hitrace/Scripts'));
addpath(genpath('../../matlab/util'));

path = '${path}';
stat = '${jobstat}';
picture_output = [path, 'scratch/figure'];
refcol = ${refcol};
offset = ${offset};
dist = ${dist};

slack = ${slack};
shift = ${shift};
windowsize = ${window};

ymin = 500;
ymax = 3000;

rdat = read_rdat_file([path, 'rdat.txt']);
sequences = {};
groups = {};
structure = rdat.structure;
% rdat grouping by sequence
for i = 1:length(rdat.data_annotations)
	annt = rdat.data_annotations{i};
	for j = 1:length(annt)
		seqstr = strfind(annt{j}, 'sequence:');
		if(~isempty(seqstr))
			sequence = annt{j}((seqstr + length('sequence:')):end);
			grp_idx = find_sequence_from_cell(sequence, sequences);
			
			if(isempty(grp_idx))
				grp_idx = length(sequences) + 1;
				sequences{grp_idx} = sequence;
				groups{grp_idx} = [];
			end
			
			groups{grp_idx} = [groups{grp_idx}, i];
			continue;
		end

		modstr = strfind(annt{j}, 'modifier:');
		if(~isempty(modstr))
			modifiers{i} = annt{j}((modstr + length('modifier:')):end);
		end
	end
end


for i = 1:length(sequences)
	seqpos = length(sequences{i}) - dist - [1:(length(sequences{i})-dist)] + 1 + offset;
	[ marks{i}, area_preds{i}, mutpos{i}] = get_predicted_marks_SHAPE_DMS_CMCT( structure, ...
			sequences{i}, offset , seqpos, modifiers(groups{i}) );
end

filenames = textread('${filelist}', '%s');

% setting status file
print_stat(2, stat);

matlabpool(8);
% done 1 stage -- basic alignment
[data data_align] = quick_look(filenames, ymin, ymax, [], [], refcol, 1);
[ymin ymax] = findTimeRange(data);
axis( [ 0.5 size(data,2)+0.5 ymin ymax] );
print([picture_output, '1.png'], '-dpng');
print_stat(3, stat);

d_align = align_by_DP_using_ref(data(ymin:ymax,:), data_align(ymin:ymax,:), [], slack, shift, windowsize, 1);
print([picture_output, '2.png'], '-dpng');
print_stat(4,stat);

d_bsub = baseline_subtract_v2(d_align , 0, 0, 0, 0, 1);
print([picture_output, '3.png'], '-dpng');

fid = fopen([path,'group_size'],'w');
fprintf(fid, '%d', length(sequences));
fclose(fid);

for i = 1:length(sequences)
	data = d_bsub(:,groups{i});
	save([path, sprintf('data%d.txt',i)], '-ascii', '-tabs', 'data');
	area_pred =area_preds{i};
	fid = fopen([path, sprintf('area_pred%d.txt', i)], 'w');
	for j=1:size(area_pred,1)
		for k = 1:size(area_pred,2)
			fprintf(fid,'%d\t', area_pred(j,k));
		end
		fprintf(fid,'\n');
	end
	fclose(fid);

	fid = fopen([path, sprintf('sequence%d.txt',i)],'w');
	fprintf(fid, '%s', sequences{i});
	fclose(fid);
end
print_stat(5,stat);
