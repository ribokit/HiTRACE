function print_stat(code, path)
fid = fopen(path, 'w');
fprintf(fid, '%d', code);
fclose(fid);
