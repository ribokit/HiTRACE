function idx = find_sequence_from_cell(target, sequences)
idx = [];

for i = 1:length(sequences)
	if(strcmp(sequences{i}, target))
		idx = i;
		break;
	end
end
