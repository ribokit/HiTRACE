<?php
	include 'php/inc/check_pid.php';
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/viewer.css"/>
<script type="text/javascript">
<?php
	echo "var pid = \"$pid\";";
?>
</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/viewer.js"></script>
</head>

<body>
<div>
<a href="/">Return top</a>
<div id="group_size"></div>
<div id="status"></div>
<div id="revert">
	<a href="/php/revert.php?pid=<?=$pid?>">revert to previous stage</a>
</div>
<form action="mark_sequence_working.php" method="get">
	<input name="gid" type="hidden" value="1" />
	<input name="pid" type="hidden" value="<?=$pid?>" />
	<input id="submit_btn" type="submit" value="Annotate!"/>
</form>
<button id="down_btn" type="button">Download fitting results</button>
<img src="img/loading.gif" id="loadingImg" />
</div>
</body>
</html>

