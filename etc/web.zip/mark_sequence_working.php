<?php
	include 'php/inc/check_pid.php';
?>
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
<?php
	$gid = $_GET["gid"];

	$group_size = file_get_contents("./tmp_data/$pid/group_size");
	echo "var pid = \"$pid\";";
	echo "var gid = $gid;";
	echo "var grp_size = $group_size;";
	echo "var dist = 20;";
?>
</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="php/preparing_data.php?gid=<?=$gid?>&pid=<?=$pid?>"></script>
<script type="text/javascript" src="js/mark_sequence.js"></script>
<link rel="stylesheet" type="text/css" href="css/mark_sequence.css"/>
</head>
<body>
<div id="title" class="header">
</div>
<div id="viewer" class="viewer">
	<canvas id="orgLayer" style="z-index: 0;" hidden="true"></canvas>
	<canvas id="bgLayer" class="layer" style="z-index: 1;"> Your browser doesn't support HTML 5.</canvas>
	<canvas id="lineLayer" class="layer" style="z-index: 2;"></canvas>
	<canvas id="charLayer" class="layer" style="z-index: 3;"></canvas>
	<canvas id="aimLayer" class="layer" style="z-index: 4;"></canvas>
</div>
</div>

<div class="panel">
	<div class="control" id="int_view" style="width:120px">Intensity: x1</div>
	<input class="control" id="int_range" type="range" max="5" min="0" value="1" step="0.5" style="width:200px;"/>
	<input class="control" id="reset_btn" type="button" value="Reset"/>
</div>

<div class="panel">
	<div class="control" id="zoom_view" style="width:120px">Zoom: x1</div>
	<input class="control" id="zoom_range" type="range" max="8" min="0.5" value="1" step="0.02" style="width:200px;"/>
</div>

<div class="panel">
	<span>Assign Action: </span>
	<input type="radio" id="add" name="clickAction" value="true" checked="true">Add
	<input type="radio" id="del" name="clickAction" value="false">Delete
	<input type="button" id="autoassign" value="Auto Assign"/>
	<img id="as_loadingImg" src="img/loading.gif" style="display:none;"/>
<div>
<div class="panel">
	<form id="submit_frm" onsubmit="return saveXsel();" method="get">
		<input type="hidden" id="gid" name="gid" value=""/>
		<input type="hidden" id="pid" name="pid" value=""/>
		<input type="submit" id="submit" value="Submit"/>
	</form>
</div>

<div class="panel" id="info_panel">
</div>

<div class="panel" id="xsel_panel">
</div>

</body>
</html>
