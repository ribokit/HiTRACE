<?php
	include 'inc/check_pid.php';
	$path = "../tmp_data/$pid/";
	$jobstat = intval(file_get_contents($path. "stat"));
	$grp_size = intval(file_get_contents($path . "group_size"));
	$archive_file = $path . "temp_archive.zip";

	if($jobstat !== 7) {
		die("the result has not been generated");
	}

	$zip = new ZipArchive();
	
	if($zip->open($archive_file, ZIPARCHIVE::CREATE) !== TRUE) {
		die("could not open archive");
	}

	for($i = 1; $i <= $grp_size; $i++) {
		$zip->addFile(sprintf("%sarea_peak%d.txt",$path,$i), sprintf("area_peak%d.txt",$i)) or die("Error: could not add file");
	}

	$zip->close();
	$archive_size = filesize($archive_file);

	header("Content-type: application/zip");
	header("Content-length: $archive_size");
	header('Content-Disposition: attachment; filename="download.zip"');
	readfile($archive_file);
	
	unlink($archive_file);
?>
