<?php
	include 'inc/matlab_generator.php';
	include 'inc/matlab_path.php';
	include 'inc/check_pid.php';
	
	if(isset($_REQUEST["gid"])) {
		$gid = $_REQUEST["gid"];
	} else {
		die("gid is missing");
	}

	$template_path = '../matlab/template/auto_assign.m';
	$path = "../tmp_data/$pid";
	$sequence = file_get_contents("$path/sequence$gid.txt");
	$AUTOASSIGN = "$path/auto_assign.m";
	$sequence = chop($sequence);

	$config = array("path" => "./",
			"output" => "scratch/auto_assign.txt",
			"sequence" => $sequence,
			"dist" => 20,
			"gid" => $gid
			);

	$generator = new MatlabGenerator($template_path);

	$generator->setArray($config);
	$body = $generator->generate();
	file_put_contents($AUTOASSIGN, $body);
	
	$descSpec = array(
			1 => array("file", "/dev/null", "w"),
			2 => array("file", "$path/debug_matlab", "w")
			);
	
	$proc = proc_open("$MATLAB_BIN -nodisplay -r \"run('$AUTOASSIGN')\"", $descSpec, $pipes);

	if(is_resource($proc)) {
		$status = proc_close($proc);

		// read from the result
		$fid = fopen("$path/". $config["output"],"r");
		
		$xsels = fgetcsv($fid,0, "\t");
		$xsels = array_splice($xsels, 0, count($xsels)-1);
		
		echo "xsel = ", json_encode($xsels), ";";

	} else {
		
	}
?>
