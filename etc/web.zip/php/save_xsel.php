<?php
	include 'inc/check_pid.php';
	$xsel = $_POST["xsel"];
	$gid = $_POST["gid"];

	$xsel = explode(",", $xsel);

	$fid = fopen("../tmp_data/$pid/xsel$gid.txt","w");	
	fputcsv($fid, $xsel, "\t");
	fclose($fid);
	echo "success";
?>
