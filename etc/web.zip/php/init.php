<?php
$path = "../tmp_data";
$stat = file_get_contents("$path/stat"); 
$pid = file_get_contents("$path/job");
if($stat == FALSE || $stat >= 7 ) { // finished or empty
	$pid = md5(rand() * time());
	while(file_exists($path . $pid)) {
		$pid = md5(rand() * time());
	}

	exec("mkdir $path/$pid");
	exec("mkdir $path/$pid/scratch");
	file_put_contents("$path/$pid/stat", "-5");
	file_put_contents("$path/job", $pid);
	exec("ln -snf $path/$pid/stat $path/stat");
	echo "$pid";
} elseif(isset($_GET["pid"]) && $stat == -5 && $pid == $_GET["pid"]) {
	exec("rm -rf $path/$pid/*");
	exec("mkdir $path/$pid/scratch");
	file_put_contents("$path/$pid/stat", "-5");
	file_put_contents("$path/job", $pid);
	exec("ln -snf $path/$pid/stat $path/stat");
	echo "$pid";
} else {
	echo "0";
}
?>
