<?php
include 'inc/check_pid.php';
header("content-type: application/x-javascript");
// initialize essential variables
//$path = $_GET["path"];
//$intensity = $_GET["intensity"];

$path = "../tmp_data/$pid/";
$gid = $_GET["gid"];
$datafile = $path . "data$gid.txt";
$seqfile = $path . "sequence$gid.txt";
$predfile = $path . "area_pred$gid.txt";
$xselfile = $path . "xsel$gid.txt";

/* sequence data reading section */

$fHandle = fopen($seqfile, "r");
$sequnce = "";

if($fHandle) {
	$buffer = fgets($fHandle);
	if($buffer !== false) {
		$sequence = $buffer;
	}
}

$sequence = chop($sequence);

fclose($fHandle);


/* sequence reading section end */




// colormap grayscale(100)
for($i=0; $i < 100; $i++) {
	$map[$i] = round(255 * (99 - $i) / 99);
}


/*
	data file loading section
*/
// read from data file
$fHandle = fopen($datafile, "r");

// file open error handling
if($fHandle == FALSE) {
	die("invalid data file");
}

$data = array();
$base = 99999;

while($line = fgetcsv($fHandle,0,"\t")) {
	$c = count($line);
	$line = array_splice($line,0,$c - 1);
	$data[] = $line;
	$min_val = min($line);
	if($base > $min_val) {
		$base = $min_val;
	}
}

//file close
fclose($fHandle);

$rows = count($data);
$cols = count($data[0]);

for($i = 0; $i < $rows; $i++) {
	for($j = 0; $j < $cols; $j++) {
		$data[$i][$j] = ($data[$i][$j] - $base);
	}
}

/* area_pred reading section */
$fHandle = fopen($predfile, "r");

// file open error handling
if($fHandle == FALSE) {
	die("invalid data file");
}

$pred = array();

while($line = fgetcsv($fHandle,0,"\t")) {
	$line = array_splice($line,0,$c - 1);
	for($i = 0; $i < count($line); $i++) {
		$line[$i] = intval($line[$i]);
	}
	$pred[] = $line;
}
fclose($fHandle);


echo "var sequence = \"$sequence\";";
echo "var colormap = ", json_encode($map), ";";
echo "var data = ", json_encode($data), ";";
echo "var area_pred = ", json_encode($pred), ";";

if(file_exists($xselfile)) {
	$fHandle = fopen($xselfile, "r");
	$xsel = fgetcsv($fHandle, 0, "\t");
	echo "var xsel= ", json_encode($xsel), ";";
} else {
	echo "var xsel = new Array();";
}
?>
