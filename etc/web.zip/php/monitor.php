<?php
	include 'inc/check_pid.php';
	$path = "../tmp_data/$pid/";
	$JOBSTAT = $path . "stat";
	$errorstat = $path . "debug_matlab";
	
	$stat = file_get_contents($JOBSTAT);
	$error = file_get_contents($errorstat);

	if($error == "") {
		echo $stat;
	} else {
		echo $error;
	}
?>
