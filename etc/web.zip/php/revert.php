<?php
	include 'inc/check_pid.php';
	$path = "../tmp_data/$pid/";
	$JOBSTAT = $path . "stat";
	$errorstat = $path . "debug_matlab";
	
	$stat = file_get_contents($JOBSTAT);
	$error = file_get_contents($errorstat);

	if($error != "") {
		switch($stat) {
			case 7:
			case 6:
				file_put_contents($JOBSTAT, "5");
				break;
			case 5:
			case 4:
			case 3:
			case 2:
				file_put_contents($JOBSTAT, "-5");
		}
		file_put_contents($errorstat, "");
	}

	header("Location: ../check.php?pid=$pid");
?>
