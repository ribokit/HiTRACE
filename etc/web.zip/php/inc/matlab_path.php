<?php
	$MATLAB_PATH="/usr/local/MATLAB/R2011b/";
	$MATLAB_BIN=$MATLAB_PATH . "bin/matlab";
?>
