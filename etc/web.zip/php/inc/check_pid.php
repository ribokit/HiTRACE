<?php
	if(isset($_REQUEST["pid"])) {
		$pid = $_REQUEST["pid"];
	} else {
		die("invalid pid");
	}
?>
