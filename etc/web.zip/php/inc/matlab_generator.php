<?php
class MatlabGenerator {
	private $template_src = null;
	private $assoc_array = null;
	private $body = null;

	function __construct($src) {
		$this->template_src = $src;
	}

	function setArray($arr) {
		$this->assoc_array = $arr;
	}
	
	function processByID() {
		$patterns = array_keys($this->assoc_array);
		for($i = 0; $i < count($patterns) ; $i++)
		{
			$patterns[$i] = '/\$\{' . $patterns[$i] .'\}/m';
		}
		$replace = array_values($this->assoc_array);
		$this->body = preg_replace($patterns, $replace, $this->body);
	}

	function generate() {
		$this->body = file_get_contents($this->template_src);

		if($this->body == FALSE)
			return FALSE;

		$this->processByID();
		return $this->body;
	}
}
?>
