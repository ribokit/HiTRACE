<?php
	include 'inc/check_pid.php';
	$path = "../tmp_data/$pid/";
	$sizefile = $path . "group_size";
	$stat = file_get_contents($sizefile);
	echo $stat;
?>
