<?php
	include 'inc/matlab_generator.php';
	include 'inc/matlab_path.php';
	include 'inc/check_pid.php';

	$path = "../tmp_data/$pid";
	$RUNNING = "$path/basic_align.m";
	$filelist = $path . "/filelist.txt";
	$JOBSTAT = $path . "/stat";

	$template_path = '../matlab/template/basic_align.m';
	
	$config = array("path" => "../" .$path . "/",
			"picture_output" => "../" . "$path/scratch/fitting.png",
			"jobstat" => "../" . $JOBSTAT,
			"filelist" => "../" . $filelist,
			"refcol" => 4,
			"offset" => 0,
			"dist" => 20,
			"slack" => 10,
			"shift" => 100,
			"window" => 100
			);
	
	$generator = new MatlabGenerator($template_path);

	$generator->setArray($config);
	$body = $generator->generate();
	file_put_contents($RUNNING, $body);	

	exec("$MATLAB_BIN -nodisplay -r \"run('$RUNNING')\" 1> /dev/null 2> $path/debug_matlab &");
	header("Location: ../viewer.php?pid=$pid");
?>
