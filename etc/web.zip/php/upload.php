<?php
	include "inc/check_pid.php";
	if(isset($_POST["action"])) {
		$action = $_POST["action"];
	} else {
		die("access violation");
	}
	$path= "../tmp_data/$pid/";

	$stat = file_get_contents($path . "stat");
	if($stat != -5) {
		die("already");
	}

	switch($action) {
		case "upload":
			$filename = $_POST["filename"];
			$data = $_POST["data"];
			
			$data = base64_decode($data);

			$fHandle = fopen($path . $filename,"a");
			fwrite($fHandle, $data);
			break;
		case "done":
			file_put_contents($path . "stat", "1"); // sign for upload complete
			break;
	}
	echo "success";
?>
