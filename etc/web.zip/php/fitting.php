<?php
	include 'inc/matlab_generator.php';
	include 'inc/matlab_path.php';
	include 'inc/check_pid.php';

	if(isset($_GET["gid"])) {
		$final_gid = $_GET["gid"];
	} else {
		die("max gid is required");
	}
	$template_path = '../matlab/template/fitting.m';
	$path = "../tmp_data/$pid/";
	$grp_size = file_get_contents($path . "group_size");
	$RUNNING = $path . "fitting.m";
	$JOBSTAT = "stat";

	$config = array("path" => "./",
			"jobstat" => $JOBSTAT,
			"grp_size" => $grp_size	
			);
	
	$generator = new MatlabGenerator($template_path);

	$generator->setArray($config);
	$body = $generator->generate();
	file_put_contents($RUNNING,$body);	
	file_put_contents($path . $JOBSTAT,"6");	

	exec("$MATLAB_BIN -nodisplay -r \"run('$RUNNING')\" 1> /dev/null 2> $path/debug_matlab &");

	header("Location: ../viewer.php?pid=$pid");
?>
